#!/usr/bin/env python3
"""
Workflow Output Fixer & Validator
==================================
Addresses the critical 75% workflow failure rate:

Problem: VHS_VideoCombine saves files to disk but ComfyUI's history API
doesn't track them in the `outputs` dict. The validator queries history,
finds 0 outputs, and correctly marks the generation as FAILED — even
though files exist on disk.

Solution: Add a SaveImage node connected to the VAEDecode output in every
workflow that lacks one. This gives ComfyUI a trackable output while
VHS_VideoCombine continues doing its thing for video.

Also includes:
  - Pre-submission workflow validation
  - Cache-busting seed randomization
  - Workflow audit report

Usage:
    python3 fix_workflow_outputs.py                    # Fix all workflows
    python3 fix_workflow_outputs.py --dry-run           # Preview changes
    python3 fix_workflow_outputs.py --validate-only     # Just check, don't fix
    python3 fix_workflow_outputs.py --audit              # Full audit report

Place at: /opt/tower-echo-brain/scripts/fix_workflow_outputs.py
"""

import argparse
import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

WORKFLOW_DIR = "/opt/tower-anime-production/workflows/comfyui"
BACKUP_SUBDIR = "backups"


# ---------------------------------------------------------------------------
# Workflow analysis
# ---------------------------------------------------------------------------

def analyze_workflow(workflow: dict) -> dict:
    """
    Deep analysis of a workflow's node graph.
    Returns a dict describing what's present, what's missing, and what's broken.
    """
    analysis = {
        "node_count": 0,
        "has_checkpoint": False,
        "has_clip_encode": False,
        "has_sampler": False,
        "has_vae_decode": False,
        "has_save_image": False,
        "has_vhs_combine": False,
        "has_preview_image": False,
        "has_empty_latent": False,
        "has_animatediff": False,
        "has_rife": False,
        "has_lora_loader": False,
        "checkpoint_model": "",
        "loras": [],
        "animatediff_model": "",
        "save_nodes": [],
        "vae_decode_node_id": None,
        "vae_decode_output_slot": 0,
        "sampler_node_id": None,
        "max_node_id": 0,
        "errors": [],
        "warnings": [],
        "output_trackable": False,  # Can ComfyUI history track the output?
    }

    for node_id, node in workflow.items():
        if not isinstance(node, dict) or "class_type" not in node:
            continue

        analysis["node_count"] += 1
        ct = node["class_type"]
        inputs = node.get("inputs", {})
        title = node.get("_meta", {}).get("title", "")

        try:
            nid = int(node_id)
            if nid > analysis["max_node_id"]:
                analysis["max_node_id"] = nid
        except ValueError:
            pass

        if ct == "CheckpointLoaderSimple":
            analysis["has_checkpoint"] = True
            analysis["checkpoint_model"] = inputs.get("ckpt_name", "")

        elif ct == "CLIPTextEncode":
            analysis["has_clip_encode"] = True

        elif ct in ("KSampler", "KSamplerAdvanced"):
            analysis["has_sampler"] = True
            analysis["sampler_node_id"] = node_id

        elif ct == "VAEDecode":
            analysis["has_vae_decode"] = True
            analysis["vae_decode_node_id"] = node_id

        elif ct == "EmptyLatentImage":
            analysis["has_empty_latent"] = True

        elif ct == "SaveImage":
            analysis["has_save_image"] = True
            analysis["save_nodes"].append({"id": node_id, "type": "SaveImage"})

        elif ct == "VHS_VideoCombine":
            analysis["has_vhs_combine"] = True
            analysis["save_nodes"].append({"id": node_id, "type": "VHS_VideoCombine"})

        elif ct == "PreviewImage":
            analysis["has_preview_image"] = True

        elif ct == "LoraLoader":
            analysis["has_lora_loader"] = True
            analysis["loras"].append(inputs.get("lora_name", ""))

        elif "AnimateDiff" in ct:
            analysis["has_animatediff"] = True
            if "model" in inputs:
                analysis["animatediff_model"] = str(inputs.get("model", ""))

        elif ct == "RIFE VFI":
            analysis["has_rife"] = True

    # Determine if output is trackable by ComfyUI history
    analysis["output_trackable"] = analysis["has_save_image"]

    # Validation errors
    if not analysis["has_checkpoint"]:
        analysis["errors"].append("No CheckpointLoaderSimple node")

    if not analysis["has_sampler"]:
        analysis["errors"].append("No KSampler node")

    if not analysis["has_vae_decode"]:
        analysis["errors"].append("No VAEDecode node — cannot produce images")

    if not analysis["has_save_image"] and not analysis["has_vhs_combine"]:
        analysis["errors"].append("No output node (SaveImage or VHS_VideoCombine)")

    # Warnings
    if analysis["has_vhs_combine"] and not analysis["has_save_image"]:
        analysis["warnings"].append(
            "VHS_VideoCombine saves to disk but ComfyUI history won't track it. "
            "Add SaveImage node for validation compatibility."
        )

    if analysis["has_rife"] and not analysis["has_animatediff"]:
        analysis["warnings"].append(
            "RIFE VFI without AnimateDiff — needs batch_size >= 2"
        )

    if analysis["has_animatediff"]:
        # Check if animatediff model file exists
        ad_model = analysis.get("animatediff_model", "")
        if ad_model and "mm-Stabilized_high" in str(ad_model):
            analysis["warnings"].append(
                f"AnimateDiff model mm-Stabilized_high.pth may not be installed. "
                f"Available: mm_sd_v15_v2.ckpt, v3_sd15_mm.ckpt"
            )

    return analysis


# ---------------------------------------------------------------------------
# Workflow fixing
# ---------------------------------------------------------------------------

def find_vae_decode_connection(workflow: dict, analysis: dict) -> tuple:
    """
    Find what feeds into the VAEDecode node and trace to a usable
    image output slot. Returns (node_id, output_slot) to connect SaveImage.
    """
    vae_node_id = analysis["vae_decode_node_id"]
    if not vae_node_id:
        return None, 0

    # The VAEDecode output (slot 0) is the decoded image
    return vae_node_id, 0


def find_image_source_for_save(workflow: dict, analysis: dict) -> tuple:
    """
    Find the best node to connect a new SaveImage node to.
    Priority: VAEDecode > PreviewImage input > VHS_VideoCombine input
    """
    # Best: direct VAEDecode output
    if analysis["vae_decode_node_id"]:
        return analysis["vae_decode_node_id"], 0

    # Fallback: find what VHS_VideoCombine is connected to
    for node_id, node in workflow.items():
        if not isinstance(node, dict):
            continue
        if node.get("class_type") == "VHS_VideoCombine":
            images_input = node.get("inputs", {}).get("images")
            if isinstance(images_input, list) and len(images_input) >= 2:
                return str(images_input[0]), int(images_input[1])

    # Fallback: find what PreviewImage is connected to
    for node_id, node in workflow.items():
        if not isinstance(node, dict):
            continue
        if node.get("class_type") == "PreviewImage":
            images_input = node.get("inputs", {}).get("images")
            if isinstance(images_input, list) and len(images_input) >= 2:
                return str(images_input[0]), int(images_input[1])

    return None, 0


def add_save_image_node(workflow: dict, analysis: dict) -> dict:
    """
    Add a SaveImage node to a workflow that lacks one.
    Connects to the VAEDecode output or traces the VHS input.
    """
    source_id, source_slot = find_image_source_for_save(workflow, analysis)

    if not source_id:
        return workflow  # Can't find a connection point

    new_id = str(analysis["max_node_id"] + 1)

    workflow[new_id] = {
        "class_type": "SaveImage",
        "inputs": {
            "filename_prefix": "validated_frame",
            "images": [source_id, source_slot],
        },
        "_meta": {
            "title": "Save Frame (validation tracker)",
        },
    }

    return workflow


def randomize_seeds(workflow: dict) -> dict:
    """
    Randomize all KSampler seeds to bust ComfyUI's execution cache.
    Without this, repeated runs return cached results with 0 new outputs.
    """
    import random

    for node_id, node in workflow.items():
        if not isinstance(node, dict):
            continue
        ct = node.get("class_type", "")
        if ct in ("KSampler", "KSamplerAdvanced"):
            node["inputs"]["seed"] = random.randint(0, 2**32 - 1)

    return workflow


# ---------------------------------------------------------------------------
# Batch operations
# ---------------------------------------------------------------------------

def fix_all_workflows(dry_run: bool = False) -> dict:
    """
    Scan all workflows, analyze, fix those missing SaveImage nodes.
    Returns summary of actions taken.
    """
    if not os.path.isdir(WORKFLOW_DIR):
        print(f"❌ Workflow directory not found: {WORKFLOW_DIR}")
        sys.exit(1)

    # Create backup dir
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(WORKFLOW_DIR, BACKUP_SUBDIR, timestamp)

    summary = {
        "scanned": 0,
        "already_ok": 0,
        "fixed": [],
        "unfixable": [],
        "errors": [],
    }

    print("\n" + "=" * 60)
    print("  WORKFLOW OUTPUT FIXER")
    print("=" * 60)

    workflows = sorted(f for f in os.listdir(WORKFLOW_DIR) if f.endswith(".json"))
    print(f"\n  Found {len(workflows)} workflow files\n")

    for wf_file in workflows:
        wf_path = os.path.join(WORKFLOW_DIR, wf_file)
        summary["scanned"] += 1

        try:
            with open(wf_path) as f:
                workflow = json.load(f)
        except Exception as e:
            summary["errors"].append(f"{wf_file}: parse error ({e})")
            print(f"  ❌ {wf_file}: JSON parse error")
            continue

        analysis = analyze_workflow(workflow)

        # Already has SaveImage — no fix needed
        if analysis["has_save_image"]:
            summary["already_ok"] += 1
            print(f"  ✅ {wf_file} — already has SaveImage")
            continue

        # Has VHS but no SaveImage — fix it
        if analysis["has_vhs_combine"] or analysis["has_vae_decode"]:
            source_id, _ = find_image_source_for_save(workflow, analysis)
            if not source_id:
                summary["unfixable"].append(
                    f"{wf_file}: can't find image source to connect SaveImage"
                )
                print(f"  ⚠️  {wf_file} — no SaveImage, can't find connection point")
                continue

            if dry_run:
                print(f"  🔧 {wf_file} — WOULD add SaveImage "
                      f"(connect to node {source_id})")
                summary["fixed"].append(wf_file)
                continue

            # Backup
            os.makedirs(backup_dir, exist_ok=True)
            shutil.copy2(wf_path, os.path.join(backup_dir, wf_file))

            # Fix
            workflow = add_save_image_node(workflow, analysis)

            with open(wf_path, "w") as f:
                json.dump(workflow, f, indent=2)

            summary["fixed"].append(wf_file)
            print(f"  🔧 {wf_file} — added SaveImage node "
                  f"(connected to node {source_id})")

        else:
            summary["unfixable"].append(
                f"{wf_file}: no VHS or VAEDecode node found"
            )
            print(f"  ⚠️  {wf_file} — no output nodes at all")

    # Summary
    print("\n" + "-" * 60)
    print(f"  Scanned:    {summary['scanned']}")
    print(f"  Already OK: {summary['already_ok']}")
    print(f"  Fixed:      {len(summary['fixed'])}")
    print(f"  Unfixable:  {len(summary['unfixable'])}")
    print(f"  Errors:     {len(summary['errors'])}")

    if not dry_run and summary["fixed"]:
        print(f"\n  Backups saved to: {backup_dir}")

    if summary["unfixable"]:
        print("\n  ⚠️  Unfixable workflows:")
        for item in summary["unfixable"]:
            print(f"    • {item}")

    print("=" * 60)
    return summary


def validate_all_workflows() -> dict:
    """Run full validation audit on all workflows."""
    if not os.path.isdir(WORKFLOW_DIR):
        print(f"❌ Workflow directory not found: {WORKFLOW_DIR}")
        sys.exit(1)

    workflows = sorted(f for f in os.listdir(WORKFLOW_DIR) if f.endswith(".json"))

    print("\n" + "=" * 60)
    print("  WORKFLOW VALIDATION AUDIT")
    print("=" * 60)

    results = {"valid": 0, "warnings": 0, "errors": 0}

    for wf_file in workflows:
        wf_path = os.path.join(WORKFLOW_DIR, wf_file)

        try:
            with open(wf_path) as f:
                workflow = json.load(f)
        except Exception as e:
            print(f"\n  ❌ {wf_file}: JSON parse error ({e})")
            results["errors"] += 1
            continue

        analysis = analyze_workflow(workflow)

        if analysis["errors"]:
            icon = "❌"
            results["errors"] += 1
        elif analysis["warnings"]:
            icon = "⚠️ "
            results["warnings"] += 1
        else:
            icon = "✅"
            results["valid"] += 1

        print(f"\n  {icon} {wf_file}")
        print(f"     Nodes: {analysis['node_count']} | "
              f"Model: {analysis['checkpoint_model'] or '?'} | "
              f"LoRAs: {len(analysis['loras'])} | "
              f"Output trackable: {'✓' if analysis['output_trackable'] else '✗'}")

        features = []
        if analysis["has_animatediff"]:
            features.append("AnimateDiff")
        if analysis["has_rife"]:
            features.append("RIFE")
        if analysis["has_lora_loader"]:
            features.append("LoRA")
        if analysis["has_vhs_combine"]:
            features.append("VHS_Video")
        if analysis["has_save_image"]:
            features.append("SaveImage")
        if features:
            print(f"     Features: {', '.join(features)}")

        for err in analysis["errors"]:
            print(f"     ❌ {err}")
        for warn in analysis["warnings"]:
            print(f"     ⚠️  {warn}")

    print("\n" + "-" * 60)
    total = results["valid"] + results["warnings"] + results["errors"]
    print(f"  Total: {total} | "
          f"Valid: {results['valid']} | "
          f"Warnings: {results['warnings']} | "
          f"Errors: {results['errors']}")

    trackable = results["valid"] + results["warnings"]
    if total > 0:
        print(f"  Output trackable: {results['valid']}/{total} "
              f"({results['valid']/total*100:.0f}%)")

    print("=" * 60)
    return results


def validate_single(workflow_path: str) -> tuple:
    """Validate a single workflow file. Returns (errors, warnings)."""
    with open(workflow_path) as f:
        workflow = json.load(f)

    analysis = analyze_workflow(workflow)
    return analysis["errors"], analysis["warnings"], analysis


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Workflow Output Fixer & Validator"
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview fixes without modifying files")
    parser.add_argument("--validate-only", action="store_true",
                        help="Just validate, don't fix")
    parser.add_argument("--audit", action="store_true",
                        help="Full audit report")
    parser.add_argument("--file", type=str,
                        help="Validate a single workflow file")

    args = parser.parse_args()

    if args.file:
        errors, warnings, analysis = validate_single(args.file)
        fname = os.path.basename(args.file)
        if errors:
            print(f"❌ {fname}:")
            for e in errors:
                print(f"  • {e}")
        if warnings:
            print(f"⚠️  {fname}:")
            for w in warnings:
                print(f"  • {w}")
        if not errors and not warnings:
            print(f"✅ {fname}: valid")
        sys.exit(1 if errors else 0)

    elif args.audit or args.validate_only:
        validate_all_workflows()

    else:
        fix_all_workflows(dry_run=args.dry_run)
